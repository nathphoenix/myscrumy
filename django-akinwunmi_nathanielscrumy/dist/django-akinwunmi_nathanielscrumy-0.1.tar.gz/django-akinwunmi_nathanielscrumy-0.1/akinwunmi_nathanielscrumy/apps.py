from django.apps import AppConfig


class AkinwunmiNathanielscrumyConfig(AppConfig):
    name = 'akinwunmi_nathanielscrumy'
